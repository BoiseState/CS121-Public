/** Dummy class to hold a piece of information.
 * @author mvail
 */
public class Item {
	private String data;
	
	public Item(String data) {
		this.data = data;
	}
	
	@Override
	public String toString() {
		return data;
	}

}
